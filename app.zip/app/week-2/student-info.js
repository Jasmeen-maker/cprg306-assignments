import Link from 'next/link';

export default function StudentInfo() {
  return (
    <main>
      <h1>Jasmeen</h1>
      <Link href="https://github.com/Jasmeen-maker">https://github.com/Jasmeen-maker</Link>
    </main>
  );
}